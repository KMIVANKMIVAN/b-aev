export class CreateCuadroDto {}
