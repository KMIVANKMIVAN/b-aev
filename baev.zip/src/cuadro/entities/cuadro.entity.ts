export class Cuadro {}
