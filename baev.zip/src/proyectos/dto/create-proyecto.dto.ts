export class CreateProyectoDto {}
