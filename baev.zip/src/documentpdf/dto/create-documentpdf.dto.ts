export class CreateDocumentpdfDto {}
