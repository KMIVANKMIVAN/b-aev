export const jwtConstants = {
  secret: 'cambiar_el_secreto_en_produccion',
};
